from db_utils import fix_users_without_salt

if __name__ == "__main__":
    fix_users_without_salt()
